clc,clear
x = 1; 
while true  
    if rem(x, 2) == 1 &&rem(x,4)==1&&rem(x,3)==0&& rem(x, 9) == 0&&  rem(x,5)==4&&rem(x,6)==3&&rem(x,7)==4&&rem(x,8)==1;
        break; 
    end  
    x = x + 1; 
end  
xx = x;