r=1.5:0.2:3;
g=0.06:0.01:0.2;
figure;
plot(r, (40*r-60)./r, 'r-');
grid on;
figure;
plot(g, (3-20*g)./g, 'r-');
grid on;





