clc,clear
prob=optimproblem('ObjectiveSense','max');
a=randi([0,10],100,150);
v=optimvar('v',1,'LowerBound',0)
x=optimvar('x',100,150,'LowerBound',0);
prob.Objective =v;
prob.Constraints.con1=sum(a.*x,1)>=v;
prob.Constraints.con2=sum(x,1)==1;
[sol,fval,flag]=solve(prob),xx=sol.x;